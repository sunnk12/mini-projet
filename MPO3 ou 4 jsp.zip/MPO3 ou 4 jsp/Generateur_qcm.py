from random import sample

def choix():
    l_quest = []
    with open('qcm_custom.txt','r',encoding='utf-8') as f:
        nbr_q = int(input("A combien de questions souhaitez-vous répondre ? : "))
        for ligne in f:
            ligne = ligne.replace('\n','').split(';;')
            l_quest.append(ligne)
        qcm = sample(l_quest,nbr_q)
    return qcm

def affichage():
    questions = choix()
    n_q = 0 # Numéro de la question
    score = 0 # Score de l'utilisateur
    for qcm in questions:
        n_q += 1
        quest = qcm[0] # La question
        prop = qcm[1] # Les propositions
        prop_sep = prop.split(';') # Séparation des propositions
        solu = qcm[2] # La solution
        print('Question',n_q)
        print(quest)
        for elt in prop_sep: # Affichage des propositions
            print(elt)
        rep = input('Quelle est votre réponse ? : ')
        if rep == solu:
            print("Bravo, c'était la bonne réponse.")
            score += 1
        else:
            print("Mauvaise réponse, la bonne était la ", solu,".")
    print("Votre score est de ", score, " sur ", n_q, ".")

affichage()